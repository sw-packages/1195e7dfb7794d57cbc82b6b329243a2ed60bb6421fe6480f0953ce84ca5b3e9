/*
 * Copyright (C) 2008 Emweb bv, Herent, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/WVectorImage.h"

namespace Wt {

WVectorImage::~WVectorImage()
{ }

}
