/*
 * Copyright (C) 2008 Emweb bv, Herent, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/WVBoxLayout.h"

namespace Wt {

WVBoxLayout::WVBoxLayout()
  : WBoxLayout(LayoutDirection::TopToBottom)
{ }

}
